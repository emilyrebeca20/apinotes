apinotes
========

API para manejo de notas implementada en Ruby 2.1.0 utilizando Sinatra.
